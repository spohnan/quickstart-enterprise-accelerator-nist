import datetime

''' Configuration file of VPC flowlogs parser '''

__author__ = "Rafael M. Koike"
__version__ = "0.2.2"
__date__ = "2016-09-19"
__maintainer__ = "Rafael M. Koike"
__email__ = "koiker@amazon.com"
__status__ = "Development"


es_host = 'search-koiker-opmzyg4doapkh7eph7xapbfdfq.us-east-1.es.amazonaws.com' # Replace this for the ElasticSearch endpoint/hostname
es_port = 443 # Default port for AWS ElasticSearch, buy if you wil use with standard installation you should use 9200
es_index = 'cwl'
es_year = datetime.datetime.now().year
es_month = datetime.datetime.now().month
es_day = datetime.datetime.now().day
es_timestamp = 'timestamp'  # fieldname that will be replaced by Timestamp
log_group = 'VPCflowlog'    # Default name of the Log Group that you are sendning the VPC flowlogs
encoding = 'utf-8'          # This is the default encoding for most part of the files, 
                            # but sometimes if the customer use latin/spanish characters you will need to change.
                            # encoding = 'iso-8859-1'

mapping = {
    'VPCflowlog': {
        "properties": {
            "@timestamp": {"type": "date" },
            "@message": { "type": "string"},
            "@owner": { "type": "string", "index": "not_analyzed"},
            "@log_group": { "type": "string", "index": "not_analyzed" },
            "@log_stream": { "type": "string"},
            "srcaddr": { "type": "ip" },
            "dstport": { "type": "string", "index": "not_analyzed" },
            "start": { "type": "date" },
            "dstaddr": { "type": "ip" },
            "version": { "type": "integer" },
            "packets": { "type": "integer" },
            "protocol": { "type": "integer" },
            "account_id": { "type": "string", "index": "not_analyzed" },
            "interface-id": { "type": "string", "index": "not_analyzed" },
            "log_status": { "type": "string", "index": "not_analyzed" },
            "bytes": { "type": "integer" },
            "srcport": { "type": "integer" },
            "action": { "type": "string", "index": "not_analyzed" },
            "end": { "type": "date" },
            "srcport_name": { "type": "string", "index": "not_analyzed" },
            "dstport_name": { "type": "string", "index": "not_analyzed" },
            "protocol_name": { "type": "string", "index": "not_analyzed" },  #Protocol name: 1 = ICMP, 6 = TCP, 17 = UDP
            "country_code" : { "type": "string", "index": "not_analyzed"},   #Country code: 'US', 'BR', 'CN', 'JP'
            "location" : { "type": "geo_point"}        #Geolocation in format of lat,lon string "41.12,-71.34"
        },
        "dynamic_templates": [
            {
                "notanalyzed": {
                    "match": "*",
                    "match_mapping_type": "string",
                    "mapping": {
                        "type": "string",
                        "index": "not_analyzed"
                    }
                }
            }
        ]
    },
    "CloudTrail": {
        "dynamic_templates": [
            {
                "notanalyzed": {
                    "match": "*",
                    "match_mapping_type": "string",
                    "mapping": {
                        "type": "string",
                        "index": "not_analyzed"
                    }
                }
            }
        ]    
    },
    "Logs": {
        "dynamic_templates": [
            {
                "notanalyzed": {
                    "match": "*",
                    "match_mapping_type": "string",
                    "mapping": {
                        "type": "string",
                        "index": "not_analyzed"
                    }
                }
            }
        ]        
    }
}

protocol = {
    1: 'ICMP',
    2: 'IGMP',
    3: 'GGP',
    4: 'IPv4',
    6: 'TCP',
    8: 'EGP',
    9: 'IGP',
    17: 'UDP',
    41: 'IPv6',
    47: 'GRE',
    50: 'ESP',
    51: 'AH',
    58: 'IPv6-ICMP',
    88: 'EIGRP',
    89: 'OSPF',
    103: 'PIM',
    106: 'QNX',
    108: 'IPComp',
    112: 'VRRP',
    115: 'L2TP',
    124: 'IS-IS',
    132: 'SCTP',
    133: 'FC'
}

port_names = {
    1: "tcpmux",
    6: "echo",
    9: "discard",
    11: "systat",
    13: "daytime",
    17: "qotd",
    19: "chargen",
    20: "ftp-data",
    21: "FTP",
    22: "SSH",
    23: "telnet",
    25: "smtp",
    37: "time",
    38: "rap",
    42: "name",
    43: "nicname",
    49: "tacacs",
    53: "DNS",
    65: "tacacs-ds",
    66: "sql-net",
    67: "boot-ps",
    69: "tftp",
    70: "gopher",
    79: "finger",
    80: "HTTP",
    88: "KERBEROS",
    109: "pop2",
    110: "POP3",
    111: "RPC",
    113: "ident",
    115: "sftp",
    118: "sqlserv",
    119: "nntp",
    123: "NTP",
    135: "epmap",
    136: "profile",
    137: "NETBIOS-NS",
    138: "NETBIOS-DGM",
    161: "SNMP",
    162: "SNMP-TRAP",
    177: "xdmcp",
    194: "IRC",
    213: "ipx",
    389: "LDAP",
    443: "HTTPS",
    500: "ISAKMP",
    512: "exec",
    513: "who",
    514: "syslog",
    989: "ftps-data",
    990: "ftps",
    993: "imaps",
    995: "pop3s",
    1080: "SOCKS",
    1159: "Oracle-OMS",
    1241: "nessus",
    1344: "ICAP",
    1433: "MS-SQL-Server",
    1434: "MS-SQL-Monitor",
    1525: "orasrv",
    1527: "tlisrv",
    1812: "radius",
    1813: "radius-acc",
    2049: "nfs",
    3128: "Squid",
    3306: "MySQL",
    3389: "RDP",
    5060: "SIP",
    5432: "PostgreSQL",
    8080: "HTTP-Alt"
}
