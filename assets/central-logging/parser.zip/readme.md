
VPC flowlogs parser
===============

This is a Python Lambda script to process VPC flowlogs and send to Elasticsearch.
This script create extra fields in Elasticsearch to make easily to visualize data.
Information included:

 - Protocol Names (1 = ICMP, 6 = TCP, 17 = UDP, etc. )
 - Port names (22 = SSH, 123 = NTP, 80 = HTTP, etc.)
 - Country ISO ( 'US', 'BR', 'CN',  'JP', etc.)
 - Geo location (Latitude, Longitude)

## Instalation & Configuration

You must extract the file, edit *config.py* and change:

 - es_host = Elasticsearch endpoint
 - es_port = Elasticsearch port (default for AWS is 80)
 - log_group = 'VPCflowlog'   # Name of the Log Group that you are sendning the VPC flowlogs

Zip again with your configuration and upload to AWS Lambda function.
Configure your VPC to send flowlogs to Cloudwatch
Configure Cloudwatch to send the VPC flowlogs thru Subscriptions to your Lambda function.

### Geoip2 Lite Database
This package come with the Max Mind Geoip2 Lite Database that is free. (But we need to include the info below) :-D

This product includes GeoLite2 data created by MaxMind, available from
<a href="http://www.maxmind.com">http://www.maxmind.com</a>.
 
> You can download monthly a new database, replace the current, zip and upload again to AWS Lambda if you wish or even pay for the complete version that comes with a more precisely data.
