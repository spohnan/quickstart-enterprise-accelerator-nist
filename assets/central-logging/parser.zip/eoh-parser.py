from __future__ import print_function

import ast
import base64
import datetime
import json
import zlib
from os import environ

import boto3
import config
import ipaddress
import geoip2.database
from elasticsearch import Elasticsearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth

''' Eye of Horus log parser to ElasticSearch '''
# This product includes GeoLite2 data created by MaxMind, available from
# <a href="http://www.maxmind.com">http://www.maxmind.com</a>.

print('[+] Eye of Horus parser to Elasticsearch')

# awsauth = AWS4Auth(access_key, secret_key, region, 'es')

config.es_index = '{0}-{1:d}.{2:02d}.{3:02d}'.format(
    config.es_index,
    config.es_year,
    config.es_month,
    config.es_day)

print('[+] Loading Geoip2 Database')
try:
    reader = geoip2.database.Reader('GeoLite2-City.mmdb')
except e:
    print('[!] Geoip2 database loading error..')

class Endpoint(object):
    def __init__(self):
        self.endpoint = None
        self.function_name = None
        self.lambda_client = boto3.client('lambda')
        self.iam_client = boto3.client('iam')
        self.es_client = boto3.client('es')
        self.index_name = '{}-{:d}-{:02d}-{:02d}'.format(
            config.es_index,
            config.es_year,
            config.es_month,
            config.es_day)


    def load(self):
        session = boto3.Session()
        credentials = session.get_credentials()
        region = environ['AWS_REGION']
        awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, 'es', session_token=credentials.token)
        endpoint_host = environ['ES_ENDPOINT']
        if not endpoint_host:
            print('[!] Unable to find endpoint from environment varibale')
            return 0
        self.endpoint = Elasticsearch(
            [{'host': endpoint_host, 'port': config.es_port}],
            http_auth=awsauth,
            use_ssl=True,
            verify_certs=True,
            connection_class=RequestsHttpConnection
        )
        print('[+] Connected to endpoint: {}'.format(endpoint_host))
        # Apply mappings
        print('[+] Creating ')
        try:
            self.endpoint.indices.create(self.index_name, body={'mappings': config.mapping}, ignore=400)

        except e:
            print('[!] Problems to create/apply new index configuration')
            print('[!] Error: {}'.format(e))


def proto_name(proto):
    return config.protocol.get(int(proto), str(proto))


def port_name(port):
    return config.port_names.get(int(port), str(port))

# Initialize the Endpoint when the function is loaded (This will reduce the overhead of connection to ES everytime a new event arive)
endpoint = Endpoint()

def lambda_handler(event, context):
    # Here is the trick. Compressed event if not auto-detected will throw an error because the header is not recognized.
    # zlib.MAXWBITS|32 do the trick
    try:
        decoded64 = zlib.decompress(base64.b64decode(event['awslogs']['data']), zlib.MAX_WBITS | 32)
    except:
        print('[!] Control/Unknown message, unable to process event')
        return 0

    # Transform the events in dict
    message = json.loads(decoded64)
    msg_type = message.get('messageType', 'OTHER')
    if  msg_type in ('CONTROL_MESSAGE', 'OTHER'):
        return 0  # Control message is not processed

    if not endpoint.function_name or not endpoint.endpoint:
        endpoint.function_name = context.function_name
        endpoint.load()

    events = message.get('logEvents', {})  # Copy only the events to send
    for row in events:
        log_status = row.get('extractedFields', {}).get('log_status', 'OTHER')
        log_group = message.get('logGroup', 'GenericLog')
        if log_status in 'NODATA':
            # Skip this row because there is no data
            print('[+] Log status: {status}'.format(status=log_status))
            if isinstance(row, dict):
                print(json.dumps(row))
            else:
                print(row)
            continue

        # Check if timestamp has miliseconds (If exists strip the last 3 digits)
        if len(str(row.get('timestamp', 0))) == 13:
            row['timestamp'] = row.get('timestamp', 1000) / 1000

        if 'flowlog' in log_group.lower():
            doc_type = 'VPCflowlog'
            es_document = flowlog_parser(row, message)

        elif 'cloudtrail' in log_group.lower():
            doc_type = 'CloudTrail'
            es_document = cloudtrail_parser(row, message)

        else:
            doc_type = 'Logs'
            es_document = generic_parser(row, message)

        endpoint.endpoint.index(index=endpoint.index_name, doc_type=doc_type, id=row['id'],
                body=json.dumps(es_document, ensure_ascii=False, encoding=config.encoding))
        print(json.dumps(es_document, ensure_ascii=False, encoding=config.encoding))

    return True  # Return True


def flowlog_parser(row, message):
    # Constuct the document to send
    es_document = {
        '@id': row.get('id'),
        '@timestamp': datetime.datetime.utcfromtimestamp(float(row.get('timestamp'))).isoformat(),
        '@message': row.get('message'),
        '@owner': message.get('owner'),
        '@log_group': message.get('logGroup'),
        '@log_stream': message.get('logStream')
    }

    for key, value in row.get('extractedFields', {}).items():
        type = config.mapping['VPCflowlog']['properties'].get(key, {}).get('type', 'string')
        if value == '-' or type == 'string':
            es_document.update({key: value})
        if type == 'integer' or type == 'byte':
            try:
                es_document.update({key: int(value)})
            except ValueError:
                print('[!] Expected int value but got an error to convert the value to int.')
        elif type == 'long' or type == 'double':
            es_document.update({key: float(value)})
        elif type == 'date':
            es_document.update({key: datetime.datetime.utcfromtimestamp(float(value)).isoformat()})
        else:
            es_document.update({key: value})

    if row.get('extractedFields', {}).get('srcaddr') == '-' or row.get('extractedFields', {}).get('dstaddr') == '-':
        print(row.get('extractedFields'))

    src_ip = ipaddress.ip_address(row.get('extractedFields', {}).get('srcaddr'))
    dst_ip = ipaddress.ip_address(row.get('extractedFields', {}).get('dstaddr'))
    if not src_ip.is_private:
        try:
            geoip = reader.city(row.get('extractedFields', {}).get('srcaddr'))
            es_document.update({'country_iso': geoip.country.iso_code})
            es_document.update({'country': geoip.country.name})
            es_document.update({'location': str(geoip.location.latitude) + ',' + str(geoip.location.longitude)})

        except geoip2.errors.AddressNotFoundError:
            es_document.update({'country_iso': 'US'})
            es_document.update({'country': 'AWS'})
            es_document.update({'location': '0,0'})

    elif not dst_ip.is_private:
        try:
            geoip = reader.city(row.get('extractedFields', {}).get('dstaddr'))
            es_document.update({'country_iso': geoip.country.iso_code})
            es_document.update({'country': geoip.country.name})
            es_document.update({'location': str(geoip.location.latitude) + ',' + str(geoip.location.longitude)})
        except geoip2.errors.AddressNotFoundError:
            es_document.update({'country_iso': 'US'})
            es_document.update({'country': 'AWS'})
            es_document.update({'location': '0,0'})

    else:
        # TODO: Set the country based on the region of the ENI
        es_document.update({'country_iso': 'US'})
        es_document.update({'country': 'AWS'})
        es_document.update({'location': '0,0'})

    es_document.update({'protocol_name': proto_name(int(row.get('extractedFields', {}).get('protocol')))})
    es_document.update({'srcport_name': port_name(int(row.get('extractedFields', {}).get('srcport')))})
    es_document.update({'dstport_name': port_name(int(row.get('extractedFields', {}).get('dstport')))})
    return es_document


def cloudtrail_parser(row, message):
    # Constuct the document to send
    es_document = dict()
    if isinstance(row.get('message'), dict):
        es_document = row['message']
    else:
        # if the message is not a JSON/dict we need to evaluate if the message is a RAW string or a JSON string encoded
        try:
            es_document = json.loads(row.get('message'))

        except ValueError:
            es_document = {'message': row.get('message')}

    es_document.setdefault('@id', row['id'])
    es_document.setdefault('@timestamp', datetime.datetime.utcfromtimestamp(float(row['timestamp'])).isoformat())
    es_document.setdefault('@message', row['message'])
    es_document.setdefault('@owner', message['owner'])
    es_document.setdefault('@log_group', message['logGroup'])
    es_document.setdefault('@log_stream', message['logStream'])
    return es_document


def generic_parser(row, message):
    # Constuct the document to send
    es_document = row.get('extractedFields', {})
    es_document.setdefault('@id', row['id'])
    es_document.setdefault('@timestamp', datetime.datetime.utcfromtimestamp(float(row['timestamp'])).isoformat())
    es_document.setdefault('@message', row['message'])
    es_document.setdefault('@owner', message['owner'])
    es_document.setdefault('@log_group', message['logGroup'])
    es_document.setdefault('@log_stream', message['logStream'])
    return es_document
